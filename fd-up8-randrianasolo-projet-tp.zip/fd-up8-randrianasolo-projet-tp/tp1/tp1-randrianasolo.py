from sklearn import *
import numpy as np
from matplotlib import pyplot as plt

if __name__ == "__main__":
    print(" ------- TP1 - RANDRIANASOLO ------- ")
    print(" Question B")
    iris_data = datasets.load_iris()
    print(" Données ")
    print(iris_data.data)

    print("\n")
    print(" Variables ")
    print(iris_data.feature_names)

    print("\n")
    print(" Classes ")
    print(iris_data.target_names)

    print("\n")
    print(" Each features mean ")
    print(iris_data.data.mean(0))

    print("\n")
    print(" Each features std ")
    print(iris_data.data.std(0))

    print("\n")
    print(" Each features max ")
    print(iris_data.data.max(0))

    print("\n")
    print(" Each features min ")
    print(iris_data.data.min(0))

    print("\n")
    print(" Data length ")
    print(iris_data.data.size / iris_data.data.shape[1])

    print("\n")
    print(" Classification ")
    print(iris_data.target)

    print("\n")
    print(" Question C")

    mnist = datasets.fetch_openml('mnist_784')

    print(" Données ")
    print(mnist.data)

    print("\n")
    print(" Data length ")
    print(mnist.data.size / mnist.data.shape[1])

    print(" Features length ")
    print(len(mnist.feature_names))

    print("\n")
    print(" Each features mean ")
    print(mnist.data.mean(0))

    print("\n")
    print(" Each features std ")
    print(mnist.data.std(0))

    print("\n")
    print(" Each features max ")
    print(mnist.data.max(0))

    print("\n")
    print(" Each features min ")
    print(mnist.data.min(0))

    print("\n")
    print(" Data length ")
    print(mnist.data.size / mnist.data.shape[1])

    print("\n")
    print(" Unique class length ")
    print(len(np.unique(mnist.target)))

    print("\n")
    print("Question D")

    mk_blobs = datasets.make_blobs(n_samples=1000, n_features=2, cluster_std=4)
    plt.figure()
    plt.scatter(mk_blobs.)
    plt.title("Question D - 3")
    plt.xlim([-15, 15])
    plt.ylim([-15, 15])
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.show()

